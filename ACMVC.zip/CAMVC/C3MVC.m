function [F, Z, V, A, w, obj] = C3MVC(X, m, k, A_old, V_old, w_old, param)

num_view = length(X);
num_samp = size(X{1}, 2);

alpha = param.alpha;
beta  = param.beta;
gamma = beta;


V = V_old;
w = w_old;
Z = zeros(m, num_samp);
F = zeros(k, num_samp);
MAX_ITER = 20;
obj = 0;

for iter = 1:MAX_ITER

    % A step
    for iv = 1:num_view
        [U, ~, G] = svd(1/w(iv)*X{iv}*Z' + beta*A_old{iv}, 'econ');
        A{iv} = U*G';
    end
    clear U G 
  
    % Z step
    tZ = 0;
    for iv = 1:num_view
        tZ = tZ + 1/w(iv)*A{iv}'*X{iv};
    end
    tZ = (tZ + alpha*V'*F)/(sum(1./w)+alpha);
%     for i = 1:num_samp
%         Z(:,i) = EProjSimplex_new(tZ(:,i));
%     end
    Z = max(tZ, 0);
    

    % F step
    [U, ~, G] = svd(V*Z, 'econ');
    F = U*G';
    clear U G 


    % V step
    [U, ~, G] = svd(alpha*F*Z'+ gamma*V_old, 'econ');
    V = U*G';
    clear U G 
    %V = (alpha*F*Z'+ gamma*V_old)/(alpha + gamma);

    % w step
    errv = zeros(1, num_view);
    for iv = 1:num_view
        err = X{iv}-A{iv}*Z;
        errv(iv) = norm(err, 'fro');
    end
    w = errv./sum(errv);
    clear err errv

%     % obj
%     s1 = 0;
%     for iv = 1:num_view
%         s1 = s1+ 1/w(iv)*norm(X{iv}-A{iv}*Z, 'fro')^2 + beta*norm(A{iv}-A_old{iv}, 'fro')^2;
%     end
%     s1 = s1 + alpha*norm(Z-V'*F, 'fro')^2  + beta*norm(V-V_old, 'fro')^2; 
%     obj(iter) = s1;

end


end