clear;
%clc;
warning off;
addpath(genpath('./'));

%% dataset
ds = {'BBCSport'};
dsPath = './data/';
resPath = './result/';
metric = {'ACC','nmi','Purity','Fscore','Precision','Recall','AR','Entropy'};

for dsi = 1:length(ds)
    % load data & make folder
    dataName = ds{dsi}; disp(dataName);
    load(strcat(dsPath,dataName));
    c = length(unique(Y));
    n = length(Y);
    
    %% param search
    opt.alpha = [1 10 1e2 1e3 1e4 1e5 1e6]; 
    opt.beta = [1 10 1e2 1e3 1e4 1e5 1e6];  
    opt.k = [1 2 3 4 5 6]*c;
    num_batch = length(X_batch); num_view = length(X);
    perf = []; 
   
    for rp1 = 1:length(opt.alpha)
        for rp2 = 1:length(opt.beta)
            for rp3 = 1:length(opt.k)
                param.alpha = opt.alpha(rp1); 
                param.beta = opt.beta(rp2);
                k = opt.k(rp3);
                F_all = []; F_batch = cell(1, num_batch);
                tic
                for t = 1:num_batch
                    if t == 1
                        [F, Z, V, A, w] = C3MVC_init(X_batch{t}, k, c, param);
                        V_old = V; A_old = A; w_old = w;
                        F_all = [F_all F];
                        F_batch{t} = F;
                     
                    else
                        [F, Z, V, A, w, obj] = C3MVC(X_batch{t}, k, c, A_old, V_old, w_old, param);
                        V_old = V; w_old = w_old; A_old = A; 
                        F_all = [F_all F];
                        F_batch{t} = F;  
                    end
                end
                toc
                [~, res_all] = myNMIACCwithmean(F_all',vertcat(Y_batch{:}),c);
                res = mean(res_all); 
                fprintf("(%.3f, %.3f, %d) ACC, NMI, Purity: %.4f, %.4f, %.4f \n", param.alpha, param.beta,k,res(1), res(2),res(3));
                perf = [perf; [param.alpha param.beta k res]];
        end
        end
    end


end
