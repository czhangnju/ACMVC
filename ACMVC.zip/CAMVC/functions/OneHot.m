function Ys = OneHot(Y)

I=eye(max(Y));
Ys=I(:,Y);

end


