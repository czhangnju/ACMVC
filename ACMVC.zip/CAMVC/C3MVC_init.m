function [F, Z, V, A, w, obj] = C3MVC_init(X, m, k, param)

num_view = length(X);
num_samp = size(X{1}, 2);

alpha = param.alpha;
for iv = 1:num_view
    A{iv} = zeros(size(X{iv},1), m);
end
V = zeros(k,m);
w = ones(1, num_view)/num_view;
Z = zeros(m, num_samp);
F = zeros(k, num_samp);
MAX_ITER = 20;

for iter = 1:MAX_ITER

    % A step
    for iv = 1:num_view
        [U, ~, G] = svd(1/w(iv)*X{iv}*Z', 'econ');
        A{iv} = U*G';
    end
    clear U G 


    % Z step
    tZ = 0;
    for iv = 1:num_view
        tZ = tZ + 1/w(iv)*A{iv}'*X{iv};
    end
    tZ = (tZ + alpha*V'*F)/(sum(1./w)+alpha);
%     for i = 1:num_samp
%         Z(:,i) = EProjSimplex_new(tZ(:,i));
%     end
    Z = max(tZ, 0);

    % F step
    [U, ~, G] = svd(V*Z, 'econ');
    F = U*G';
   clear U G  
    %F = V*Z;

    % V step
    [U, ~, G] = svd(alpha*F*Z', 'econ');
    V = U*G';
    clear U G 
     %V = F*Z';
    

    % w step
    errv = zeros(1, num_view);
    for iv = 1:num_view
        err = X{iv}-A{iv}*Z;
        errv(iv) = norm(err, 'fro');
    end
    w = errv./sum(errv);
    clear err errv

    % obj
    s1 = 0;
    for iv = 1:num_view
        s1 = s1+ 1/w(iv)*norm(X{iv}-A{iv}*Z, 'fro')^2;
    end
    s1 = s1 + alpha*norm(Z-V'*F, 'fro')^2;
    obj(iter) = s1;
end


end